// const products = require("../../products");

// const getProducts = async (req, res) => {
//   try {
//     const response = products.slice(0, 1);

//     return res.status(200).json({ success: true, data: response });
//   } catch (error) {
//     return res.status(500).send({ succes: false, message: error.message });
//   }
// };
// module.exports = { getProducts };
